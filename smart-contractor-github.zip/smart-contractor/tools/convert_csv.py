"""Convert the provided CSV without synthesizing or changing records."""
import argparse
import csv
import json
from pathlib import Path


def convert(source: Path, target: Path):
    profiles = []
    with source.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            for field in ("categories", "event_formats", "languages", "busy_dates"):
                row[field] = [part.strip() for part in row[field].split("|") if part.strip()]
            for field in ("synthetic", "city_imputed", "price_imputed"):
                row[field] = row[field].casefold() == "true"
            row["price_from_kzt"] = int(row["price_from_kzt"])
            row["max_hours"] = int(row["max_hours"]) if row["max_hours"] else None
            profiles.append(row)
    target.write_text("".join(json.dumps(p, ensure_ascii=False) + "\n" for p in profiles), encoding="utf-8")
    print(f"Converted {len(profiles)} profiles; synthetic: {sum(p['synthetic'] for p in profiles)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    args = parser.parse_args()
    convert(args.source, args.target)
