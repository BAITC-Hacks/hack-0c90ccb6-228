"""Choose reproducible demo cases from the real catalog, checking their outcomes."""
import json
import sys
from datetime import timedelta
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from matcher import load_catalog, match
from models import DATE_MIN, MatchRequest


def build():
    catalog = load_catalog(ROOT / "hackathon-dataset-anonymized.jsonl")
    base = dict(city="Алматы", category="Ведущий", event_format="корпоратив", budget=1_500_000)
    dates = [(DATE_MIN + timedelta(days=i)).isoformat() for i in range(100)]
    dense = next(dict(base, event_date=day) for day in dates[:50]
                 if match(catalog, MatchRequest(**base, event_date=day))["eligible_count"] > 3)
    dense_ids = [p.id for p in match(catalog, MatchRequest(**dense))["selected"]]
    alternate = next(dict(base, event_date=day) for day in dates[:50]
                     if day != dense["event_date"] and
                     [p.id for p in match(catalog, MatchRequest(**base, event_date=day))["selected"]] != dense_ids)
    rare_base = dict(city="Алматы", category="Флорист", event_format="свадьба", budget=500_000)
    rare = next(dict(rare_base, event_date=day) for day in dates
                if 0 < match(catalog, MatchRequest(**rare_base, event_date=day))["eligible_count"] < 3)
    full_base = dict(city="Алматы", category="Банкетный зал", event_format="корпоратив", budget=100_000_000)
    full = next((dict(full_base, event_date=day) for day in dates[69:]
                if match(catalog, MatchRequest(**full_base, event_date=day))["funnel"][2]["remaining"] == 0),
                dict(full_base, event_date=dates[-1], budget=1))
    categories = sorted({c for p in catalog for c in p.categories})
    missing_category = next(c for c in categories if not any(p.city == "Астана" and c in p.categories for p in catalog))
    absent = dict(city="Астана", category=missing_category, event_date=dates[10], event_format="корпоратив", budget=1_000_000)
    cases = [("Ведущие осенью", "Плотная категория: прошли больше трёх, работает ранжирование.", dense),
             ("Другая дата", "Те же условия, другой день: состав подборки меняется из-за занятости.", alternate),
             ("Редкая категория", "Флористы: неполная выдача с объяснением причин.", rare),
             ("Нет совпадений", "Профили есть, но не проходят условия: показываем аудит.", full),
             ("Нет категории", "В выбранном городе категория отсутствует.", absent)]
    demos = [{"label": label, "description": description, "query": query,
              "expected_status": match(catalog, MatchRequest(**query))["status"]}
             for label, description, query in cases]
    (ROOT / "demo-queries.json").write_text(json.dumps(demos, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for item in demos:
        result = match(catalog, MatchRequest(**item["query"]))
        print(item["label"], item["query"]["event_date"], result["status"], result["eligible_count"])


if __name__ == "__main__":
    build()
