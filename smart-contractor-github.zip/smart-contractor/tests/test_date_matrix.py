"""Run the actual browser filter in Node and compare it with the server matcher."""
import json
import os
import shutil
import subprocess
from datetime import date, timedelta
from pathlib import Path

import pytest

from matcher import load_catalog, match
from models import DATE_MAX, DATE_MIN, MatchRequest

ROOT = Path(__file__).resolve().parents[1]
NODE = os.getenv("NODE_BINARY") or shutil.which("node")
pytestmark = pytest.mark.skipif(not NODE, reason="Node.js is required for frontend parity tests")


def run_matrices(queries, profiles, minimum=DATE_MIN, maximum=DATE_MAX, timezone="UTC"):
    script = """
      const {getDateMatrix} = require('./static/date-matrix.js');
      const input = JSON.parse(require('node:fs').readFileSync(0, 'utf8'));
      process.stdout.write(JSON.stringify(input.queries.map(query => {
        try {
          return getDateMatrix(query.event_date, query, input.profiles, input.min, input.max);
        } catch (error) { return {error: error.name}; }
      })));
    """
    result = subprocess.run([NODE, "-e", script], cwd=ROOT,
        input=json.dumps({"queries": queries, "profiles": profiles,
                         "min": str(minimum), "max": str(maximum)}),
        capture_output=True, text=True, encoding="utf-8", check=True,
        env=os.environ | {"TZ": timezone}, timeout=30)
    return json.loads(result.stdout)


def test_matrix_matches_server_for_every_calendar_day_and_all_filters():
    catalog = load_catalog(ROOT / "hackathon-dataset-anonymized.jsonl")
    demos = json.loads((ROOT / "demo-queries.json").read_text(encoding="utf-8"))
    scenarios = [demo["query"] for demo in demos]
    base = scenarios[0]
    scenarios += [base | {"budget": 700_000}, base | {"budget": 1},
                  base | {"language": "казахский"}, base | {"language": "русский"},
                  base | {"duration_hours": 10},
                  base | {"language": "английский", "duration_hours": 6, "blind_mode": True},
                  base | {"event_format": "свадьба", "duration_hours": 4}]
    queries = [params | {"event_date": (DATE_MIN + timedelta(days=offset)).isoformat()}
               for params in scenarios for offset in range((DATE_MAX - DATE_MIN).days + 1)]
    matrices = run_matrices(queries, [p.model_dump(mode="json") for p in catalog])
    seen_counts = set()
    for query, matrix in zip(queries, matrices):
        assert len(matrix) == 7
        assert [item["selected"] for item in matrix] == [False, False, False, True, False, False, False]
        assert matrix[3]["date"] == query["event_date"]
        for offset, item in enumerate(matrix, start=-3):
            expected_day = date.fromisoformat(query["event_date"]) + timedelta(days=offset)
            assert item["date"] == expected_day.isoformat()
            if DATE_MIN <= expected_day <= DATE_MAX:
                expected = match(catalog, MatchRequest(**(query | {"event_date": expected_day})))
                assert item["inRange"]
                assert item["count"] == expected["eligible_count"], (query, item, expected)
                seen_counts.add(item["count"])
            else:
                assert not item["inRange"] and item["count"] is None
    assert {0, 1, 2, 3, 4} <= seen_counts  # Counts are not capped at three cards.


@pytest.mark.parametrize("timezone", ["Asia/Qyzylorda", "America/Los_Angeles", "Pacific/Kiritimati"])
def test_matrix_calendar_boundaries_leap_days_and_timezones(timezone):
    dates = ["2026-12-31", "2026-09-23", "2026-10-31", "2028-02-29"]
    queries = [{"event_date": value} for value in dates]
    matrices = run_matrices(queries, [], date(2026, 1, 1), date(2028, 12, 31), timezone)
    for center, matrix in zip(dates, matrices):
        expected = [(date.fromisoformat(center) + timedelta(days=i)).isoformat() for i in range(-3, 4)]
        assert [item["date"] for item in matrix] == expected
        assert all(item["count"] == 0 and item["inRange"] for item in matrix)


def test_matrix_rejects_invalid_dates_instead_of_silently_rolling_over():
    invalid = ["", "2026-02-30", "2026-13-01", "2026-9-23", "not-a-date"]
    assert run_matrices([{"event_date": value} for value in invalid], []) == [
        {"error": "RangeError"} for _ in invalid]
