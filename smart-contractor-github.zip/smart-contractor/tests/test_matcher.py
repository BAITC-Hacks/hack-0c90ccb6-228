import json
from datetime import date, timedelta
from pathlib import Path
import pytest
from pydantic import ValidationError
from matcher import load_catalog, match
from models import DATE_MIN, MatchRequest, Profile

ROOT = Path(__file__).resolve().parents[1]


def profile(id="A", **changes):
    data = dict(id=id, anon_name="Тест Имя", categories=["Ведущий"], city="Алматы",
                price_from_kzt=100, event_formats=["свадьба"], languages=["русский"],
                max_hours=6, busy_dates=[], description="Выступает на скрипке; опыт более 12 лет.")
    return Profile(**(data | changes))


def request(**changes):
    return MatchRequest(**(dict(city="Алматы", category="Ведущий", event_date="2026-10-10",
                               event_format="свадьба", budget=1000) | changes))


def test_ranking_budget_then_id_and_top_three():
    rows = [profile("D", price_from_kzt=800), profile("B", price_from_kzt=900),
            profile("C", price_from_kzt=700), profile("A", price_from_kzt=900), profile("E")]
    for ordering in (rows, list(reversed(rows))):
        result = match(ordering, request())
        assert [p.id for p in result["selected"]] == ["A", "B", "D"]
        assert result["eligible_count"] == 5


def test_sequential_audit_no_double_counting():
    rows = [profile("city", city="Астана"), profile("busy", busy_dates=[date(2026, 10, 10)], price_from_kzt=2000),
            profile("money", price_from_kzt=2000), profile("format", event_formats=["той"]),
            profile("language", languages=["английский"]), profile("duration", max_hours=2)]
    result = match(rows, request(language="русский", duration_hours=4))
    assert result["status"] == "NO_CANDIDATES_MATCHED"
    assert result["excluded"] == dict(city=1, date=1, budget=1, format=1, language=1, duration=1)
    assert "заняты" in result["message"] and "бюджета" in result["message"]


def test_missing_category_differs_from_empty_results():
    assert match([profile(city="Астана")], request())["status"] == "CITY_CATEGORY_NOT_FOUND"
    assert match([profile(price_from_kzt=2000)], request())["status"] == "NO_CANDIDATES_MATCHED"


def test_null_duration_and_exact_price_boundary():
    result = match([profile(max_hours=None, price_from_kzt=1000)], request(duration_hours=12))
    assert result["status"] == "SUCCESS"
    assert result["partial_reason"]
    assert len(result["selected"]) == 1


@pytest.mark.parametrize("field,value", [("budget", 0), ("budget", "100"), ("budget", True),
    ("event_date", "2026-09-22"), ("event_date", "2027-01-01"), ("event_date", "2026-10-10T00:00:00Z"),
    ("duration_hours", 0), ("duration_hours", 1.5), ("city", " ")])
def test_invalid_input(field, value):
    with pytest.raises(ValidationError):
        request(**{field: value})


def test_real_catalog_and_demo_cases():
    catalog = load_catalog(ROOT / "hackathon-dataset-anonymized.jsonl")
    assert len(catalog) == 66
    assert sum(p.synthetic for p in catalog) == 13
    demos = json.loads((ROOT / "demo-queries.json").read_text(encoding="utf-8"))
    results = [match(catalog, MatchRequest(**demo["query"])) for demo in demos]
    assert [r["status"] for r in results] == [d["expected_status"] for d in demos]
    assert results[0]["eligible_count"] > 3
    assert 0 < results[2]["eligible_count"] < 3
    assert [p.id for p in results[0]["selected"]] != [p.id for p in results[1]["selected"]]


def test_real_catalog_calendar_invariants():
    catalog = load_catalog(ROOT / "hackathon-dataset-anonymized.jsonl")
    for offset in range(100):
        req = request(event_date=DATE_MIN + timedelta(days=offset), event_format="корпоратив", budget=1_500_000)
        result = match(catalog, req)
        assert len(result["selected"]) <= 3
        assert sum(result["excluded"].values()) + result["eligible_count"] == result["funnel"][0]["remaining"]
        for p in result["selected"]:
            assert req.event_date not in p.busy_dates
            assert p.price_from_kzt <= req.budget
            assert p.city == req.city and req.event_format in p.event_formats
