import json
from pathlib import Path
from fastapi.testclient import TestClient
from main import app
from llm_explainer import Explainer

ROOT = Path(__file__).resolve().parents[1]


def test_api_all_outcomes_blind_mode_and_health():
    demos = json.loads((ROOT / "demo-queries.json").read_text(encoding="utf-8"))
    with TestClient(app) as client:
        app.state.explainer = Explainer()
        assert client.get("/").status_code == 200
        assert client.get("/static/app.js").status_code == 200
        assert client.get("/static/date-matrix.js").status_code == 200
        assert client.get("/healthz").json()["profiles"] == 66
        assert client.get("/api/meta").json()["synthetic_count"] == 13
        for demo in demos:
            response = client.post("/api/match", json=demo["query"])
            assert response.status_code == 200
            assert response.json()["status"] == demo["expected_status"]
        normal = client.post("/api/match", json=demos[0]["query"]).json()
        blind = client.post("/api/match", json=demos[0]["query"] | {"blind_mode": True}).json()
        assert normal["explanation_mode"] == "catalog"
        assert normal["notice"]
        assert [c["id"] for c in normal["candidates"]] == [c["id"] for c in blind["candidates"]]
        assert len({c["explanation"] for c in blind["candidates"]}) == len(blind["candidates"])
        for index, (a, b) in enumerate(zip(normal["candidates"], blind["candidates"]), start=1):
            assert b["name"] == f"Кандидат #{index}"
            assert a["name"] not in json.dumps(b, ensure_ascii=False)
            assert a["explanation"] == b["explanation"]
        invalid = client.post("/api/match", json=demos[0]["query"] | {"budget": -1})
        assert invalid.status_code == 422 and invalid.json()["errors"][0]["field"] == "budget"
        assert client.get("/.env").status_code == 404
        assert client.get("/hackathon-dataset-anonymized.jsonl").status_code == 404


def test_matrix_metadata_contains_only_real_matching_fields():
    with TestClient(app) as client:
        meta = client.get("/api/meta").json()
        fields = {"categories", "city", "price_from_kzt", "event_formats",
                  "languages", "max_hours", "busy_dates"}
        assert len(meta["availability_profiles"]) == meta["profile_count"] == 66
        for row, profile in zip(meta["availability_profiles"], app.state.catalog):
            assert set(row) == fields
            assert row == profile.model_dump(mode="json", include=fields)
        assert meta["date_min"] == "2026-09-23"
        assert meta["date_max"] == "2026-12-31"


def test_rate_limit(monkeypatch):
    monkeypatch.setenv("RATE_LIMIT_PER_MINUTE", "2")
    with TestClient(app) as client:
        app.state.explainer = Explainer()
        assert client.post("/api/match", json={}).status_code == 422
        assert client.post("/api/match", json={}).status_code == 422
        response = client.post("/api/match", json={})
        assert response.status_code == 429 and response.headers["Retry-After"] == "60"
