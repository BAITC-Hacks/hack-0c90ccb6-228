"use strict";

const byId = (id) => document.getElementById(id);
const form = byId("contractor-form");
const money = new Intl.NumberFormat("ru-RU");
const fieldLabels = {city: "Город", category: "Категория", event_date: "Дата", event_format: "Формат", budget: "Бюджет", language: "Язык", duration_hours: "Длительность"};
let busy = false;
let configured = false;
let hasResults = false;
let availabilityProfiles = [];
let retryAction = initialize;

function element(tag, classes, text) {
  const node = document.createElement(tag);
  if (classes) node.className = classes;
  if (text !== undefined) node.textContent = text;
  return node;
}

function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  svg.setAttribute("class", "h-3.5 w-3.5 shrink-0 text-mint/85");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "1.3");
  svg.setAttribute("aria-hidden", "true");
  use.setAttribute("href", `#icon-${name}`);
  svg.append(use);
  return svg;
}

function fillSelect(id, values, placeholder) {
  byId(id).replaceChildren();
  if (placeholder) byId(id).add(new Option(placeholder, ""));
  for (const value of values) {
    byId(id).add(new Option(value.charAt(0).toUpperCase() + value.slice(1), value));
  }
}

function readForm() {
  return {city: byId("city").value, category: byId("category").value,
    event_date: byId("event-date").value, event_format: byId("event-format").value,
    budget: Number(byId("budget").value), duration_hours: byId("duration").value ? Number(byId("duration").value) : null,
    language: byId("language").value || null, blind_mode: byId("blind-mode").checked};
}

function applyQuery(query) {
  const mapping = {city: "city", category: "category", event_date: "event-date", event_format: "event-format", budget: "budget", language: "language", duration_hours: "duration"};
  for (const [field, id] of Object.entries(mapping)) byId(id).value = query[field] ?? "";
}

function setControlsDisabled(disabled) {
  Array.from(form.elements).forEach((control) => { control.disabled = disabled; });
  document.querySelectorAll(".demo-chip").forEach((button) => { button.disabled = disabled; });
  document.querySelectorAll(".date-card").forEach((button) => {
    button.disabled = disabled || button.dataset.outside === "true";
  });
}

async function requestJSON(path, options = {}, timeoutMs = 12000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(path, {...options, signal: controller.signal});
    let data;
    try { data = await response.json(); }
    catch { throw new Error("Сервер вернул некорректный ответ. Попробуйте ещё раз."); }
    if (!response.ok) {
      let detail = typeof data.detail === "string" ? data.detail : "Не удалось выполнить запрос.";
      if (Array.isArray(data.errors) && data.errors.length) {
        detail += ` Поле: ${fieldLabels[data.errors[0].field] || "параметры события"}.`;
      }
      throw new Error(detail);
    }
    return data;
  } catch (error) {
    if (error.name === "AbortError") throw new Error("Сервер отвечает дольше обычного. Повторите запрос через несколько секунд.");
    if (error instanceof TypeError) throw new Error("Нет связи с сервером. Проверьте подключение и попробуйте ещё раз.");
    throw error;
  } finally { clearTimeout(timeout); }
}

function showError(error) {
  byId("initial-state").hidden = true;
  byId("result-content").hidden = true;
  byId("funnel-panel").hidden = true;
  byId("date-matrix-panel").hidden = true;
  byId("result-time").textContent = "";
  byId("result-caption").textContent = "Запрос не завершён";
  byId("error-message").textContent = error.message;
  byId("error-state").hidden = false;
}

function renderFunnel(data) {
  byId("funnel-panel").hidden = false;
  byId("eligible-count").textContent = `Все условия прошли: ${data.eligible_count}`;
  byId("funnel").replaceChildren();
  data.funnel.slice(0, 4).forEach((stage, index) => {
    const item = element("li", "min-w-0");
    const row = element("div", "flex items-center justify-between");
    row.append(element("span", "text-[25px] font-medium tracking-tight text-white/85", stage.remaining));
    if (index < 3) {
      const connector = element("span", "step-connector hidden sm:block");
      connector.setAttribute("aria-hidden", "true");
      row.append(connector);
    }
    item.append(row, element("span", "mt-1 block text-[10px] leading-relaxed text-white/60", stage.label));
    byId("funnel").append(item);
  });
  byId("audit-list").replaceChildren();
  data.funnel.slice(1).forEach((stage) => byId("audit-list").append(element("li", "", `${stage.label}: осталось ${stage.remaining}, исключено ${stage.excluded}`)));
}

function variantLabel(count) {
  const plural = new Intl.PluralRules("ru-RU").select(count);
  return `${count} ${{one: "вариант", few: "варианта", many: "вариантов", other: "варианта"}[plural]}`;
}

function renderDateMatrix(selectedDate, formParams, dataset) {
  const days = getDateMatrix(selectedDate, formParams, dataset, byId("event-date").min, byId("event-date").max);
  const row = byId("date-matrix");
  const weekday = new Intl.DateTimeFormat("ru-RU", {weekday: "short", timeZone: "UTC"});
  const shortDate = new Intl.DateTimeFormat("ru-RU", {day: "numeric", month: "short", timeZone: "UTC"});
  const longDate = new Intl.DateTimeFormat("ru-RU", {day: "numeric", month: "long", year: "numeric", timeZone: "UTC"});
  row.replaceChildren();
  days.forEach((day) => {
    const date = new Date(`${day.date}T00:00:00Z`);
    const label = !day.inRange ? "Вне календаря" : day.count === 0 ? "Нет мест" : variantLabel(day.count);
    const button = element("button", "date-card bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:bg-white/10 transition-all duration-300 cursor-pointer p-3 min-w-[90px] text-center");
    button.type = "button";
    button.dataset.date = day.date;
    button.dataset.outside = String(!day.inRange);
    button.dataset.availability = !day.inRange ? "outside" : day.count === 0 ? "none" : day.count < 3 ? "few" : "many";
    button.setAttribute("aria-pressed", String(day.selected));
    button.setAttribute("aria-label", `${longDate.format(date)}, ${label}`);
    button.disabled = busy || !day.inRange;
    button.append(element("span", "date-card-weekday", weekday.format(date)),
      element("span", "date-card-date", shortDate.format(date).replace(/\.$/, "")),
      element("span", "date-card-count", label));
    button.addEventListener("click", () => {
      if (busy || !day.inRange) return;
      byId("event-date").value = day.date;
      submit();
    });
    row.append(button);
  });
  byId("date-matrix-panel").hidden = false;
  byId("date-matrix-status").textContent = `${longDate.format(new Date(`${selectedDate}T00:00:00Z`))} · ${variantLabel(days[3].count)}`;
  // Only the carousel scrolls; changing a date must not jump the entire page.
  requestAnimationFrame(() => {
    const active = row.querySelector('[aria-pressed="true"]');
    if (active) row.scrollTo({left: active.offsetLeft + active.offsetWidth / 2 - row.clientWidth / 2, behavior: "instant"});
  });
}

function renderCard(candidate, index, request) {
  const card = byId("candidate-template").content.firstElementChild.cloneNode(true);
  const field = (name) => card.querySelector(`[data-field="${name}"]`);
  const nameId = `candidate-name-${index + 1}`;
  card.setAttribute("aria-labelledby", nameId);
  field("name").id = nameId;
  field("name").textContent = candidate.name;
  field("rank").textContent = `${String(index + 1).padStart(2, "0")} / ВАША ПОДБОРКА`;
  field("initials").textContent = request.blind_mode ? String(index + 1).padStart(2, "0") : candidate.name.split(/\s+/).slice(0, 2).map((part) => part.charAt(0)).join("");
  [candidate.category, candidate.city].forEach((text) => field("tags").append(element("span", "rounded-full bg-white/10 px-3 py-1 text-[10px] text-white/80", text)));
  if (candidate.synthetic) field("tags").append(element("span", "rounded-full border border-champagne/20 bg-champagne/10 px-3 py-1 text-[10px] text-champagne", "Синтетический профиль"));
  field("price").textContent = money.format(candidate.price_from_kzt);
  field("remainder").textContent = `${money.format(request.budget - candidate.price_from_kzt)} ₸ остаётся в бюджете`;
  const date = new Date(`${candidate.available_on}T12:00:00`).toLocaleDateString("ru-RU", {day: "numeric", month: "long"});
  const conditions = [["calendar", `Свободен ${date}`], ["clock", candidate.max_hours === null ? "Без лимита часов присутствия" : `До ${candidate.max_hours} ч`]];
  conditions.forEach(([symbol, text]) => {
    const item = element("span", "inline-flex items-center gap-1.5");
    item.append(icon(symbol), document.createTextNode(text));
    field("conditions").append(item);
  });
  field("conditions").append(element("span", "inline-flex items-center gap-1.5", candidate.languages.join(" · ")));
  field("explanation").textContent = candidate.explanation;
  candidate.evidence.forEach((fact) => field("evidence").append(element("li", "", fact)));
  const notes = [];
  if (candidate.price_imputed) notes.push("Цена дополнена при подготовке датасета");
  if (candidate.city_imputed) notes.push("город дополнен при подготовке датасета");
  if (notes.length) { field("notes").hidden = false; field("notes").textContent = `${notes.join("; ")}.`; }
  return card;
}

function render(data) {
  renderFunnel(data);
  renderDateMatrix(data.request.event_date, data.request, availabilityProfiles);
  byId("result-content").hidden = false;
  byId("candidate-list").replaceChildren();
  byId("empty-state").hidden = data.status === "SUCCESS";
  byId("partial-banner").hidden = !data.partial_reason;
  byId("partial-banner").textContent = data.partial_reason || "";
  byId("price-note").hidden = data.status !== "SUCCESS";
  byId("mode-notice").hidden = !data.notice;
  byId("mode-notice").textContent = data.notice || "";
  byId("result-time").textContent = `${(data.elapsed_ms / 1000).toFixed(2)} с · ${data.request.event_date.split("-").reverse().join(".")}`;
  byId("result-caption").textContent = data.status === "SUCCESS" ? `В подборке: ${data.candidates.length} из 3` : "Подходящих вариантов пока нет";
  if (data.status === "SUCCESS") {
    data.candidates.forEach((candidate, index) => byId("candidate-list").append(renderCard(candidate, index, data.request)));
  } else {
    const missing = data.status === "CITY_CATEGORY_NOT_FOUND";
    byId("empty-title").textContent = missing ? "В этом городе пока нет такой категории" : "Кандидаты не найдены";
    byId("empty-reason").textContent = data.message;
    byId("empty-suggestion").textContent = missing ? "Выберите другой город или категорию." : "Измените дату, бюджет или дополнительные условия.";
  }
}

async function submit(event) {
  if (event) event.preventDefault();
  if (busy || !configured || !form.reportValidity()) return;
  const payload = readForm();
  const focusMatrix = byId("date-matrix").contains(document.activeElement);
  busy = true;
  retryAction = submit;
  setControlsDisabled(true);
  byId("date-matrix-panel").setAttribute("aria-busy", "true");
  byId("date-matrix-status").textContent = "Обновляем подборку…";
  byId("initial-state").hidden = true;
  byId("result-content").hidden = true;
  byId("funnel-panel").hidden = true;
  byId("error-state").hidden = true;
  byId("loading-state").hidden = false;
  byId("results-region").setAttribute("aria-busy", "true");
  byId("result-caption").textContent = "Проверяем ваши условия…";
  byId("result-time").textContent = "";
  byId("submit-label").textContent = "Подбираем варианты…";
  try {
    const data = await requestJSON("/api/match", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)});
    render(data);
    hasResults = true;
  } catch (error) { showError(error); }
  finally {
    busy = false;
    setControlsDisabled(false);
    byId("date-matrix-panel").setAttribute("aria-busy", "false");
    if (focusMatrix && !byId("date-matrix-panel").hidden) {
      byId("date-matrix").querySelector('[aria-pressed="true"]').focus({preventScroll: true});
    }
    byId("loading-state").hidden = true;
    byId("results-region").setAttribute("aria-busy", "false");
    byId("submit-label").textContent = "Найти идеального подрядчика";
  }
}

async function initialize() {
  if (busy) return;
  busy = true;
  configured = false;
  retryAction = initialize;
  setControlsDisabled(true);
  byId("retry-button").disabled = true;
  try {
    const meta = await requestJSON("/api/meta");
    availabilityProfiles = meta.availability_profiles;
    fillSelect("city", meta.cities);
    fillSelect("category", meta.categories);
    fillSelect("event-format", meta.event_formats);
    fillSelect("language", meta.languages, "Любой");
    byId("event-date").min = meta.date_min;
    byId("event-date").max = meta.date_max;
    byId("catalog-summary").textContent = `${meta.profile_count} профилей · ${meta.synthetic_count} синтетических · календарь: 23.09–31.12.2026`;
    byId("demo-list").replaceChildren();
    meta.demos.forEach((demo) => {
      const button = element("button", "demo-chip rounded-full border border-white/15 bg-white/5 px-3 py-2 text-[10px] text-white/70 transition-all duration-300 hover:scale-105 hover:bg-white/15 hover:text-white", demo.label);
      button.type = "button";
      button.title = demo.description;
      button.addEventListener("click", () => { applyQuery(demo.query); submit(); });
      byId("demo-list").append(button);
    });
    if (meta.demos.length) applyQuery(meta.demos[0].query);
    configured = true;
    byId("error-state").hidden = true;
    byId("initial-state").hidden = false;
    byId("result-caption").textContent = "Выберите условия вашего события";
  } catch (error) { showError(error); }
  finally { busy = false; setControlsDisabled(!configured); byId("retry-button").disabled = false; }
}

form.addEventListener("submit", submit);
// Counts describe the last submitted filters. Hide them while those filters are edited.
form.addEventListener("input", (event) => {
  if (event.target.id !== "blind-mode" && !busy) byId("date-matrix-panel").hidden = true;
});
byId("blind-mode").addEventListener("change", () => { if (hasResults && !busy) submit(); });
byId("reset-button").addEventListener("click", () => { byId("city").focus(); });
byId("retry-button").addEventListener("click", () => retryAction());
initialize();
