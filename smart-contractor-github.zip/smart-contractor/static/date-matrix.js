"use strict";

/** Count all eligible profiles, before the three-card limit. Keep parity with matcher.py. */
function getDateMatrix(selectedDate, formParams, dataset, dateMin, dateMax) {
  const center = new Date(`${selectedDate}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(selectedDate) || Number.isNaN(center.getTime()) ||
      center.toISOString().slice(0, 10) !== selectedDate) {
    throw new RangeError("Некорректная дата для матрицы доступности");
  }
  return Array.from({length: 7}, (_, index) => {
    // UTC calendar arithmetic does not shift dates across local time zones or DST.
    const day = new Date(center);
    day.setUTCDate(day.getUTCDate() + index - 3);
    const date = day.toISOString().slice(0, 10);
    const inRange = (!dateMin || date >= dateMin) && (!dateMax || date <= dateMax);
    const count = inRange ? dataset.filter((profile) =>
      profile.categories.includes(formParams.category) &&
      profile.city === formParams.city &&
      !profile.busy_dates.includes(date) &&
      profile.price_from_kzt <= formParams.budget &&
      profile.event_formats.includes(formParams.event_format) &&
      (!formParams.language || profile.languages.includes(formParams.language)) &&
      (formParams.duration_hours == null || profile.max_hours == null ||
        profile.max_hours >= formParams.duration_hours)
    ).length : null;
    return {date, count, inRange, selected: index === 3};
  });
}

// The same browser code is exercised against the Python matcher in tests.
if (typeof module !== "undefined" && module.exports) module.exports = {getDateMatrix};
