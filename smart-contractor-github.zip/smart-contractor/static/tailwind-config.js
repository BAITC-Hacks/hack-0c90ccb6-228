tailwind.config = {
      theme: {
        extend: {
          fontFamily: { sans: ['Inter', 'sans-serif'] },
          colors: {
            midnight: '#101126',
            champagne: '#F6D8AB',
            lilac: '#D2C2FF',
            mint: '#A5E3C3'
          },
          boxShadow: {
            glow: '0 0 38px rgba(168, 111, 241, .36), 0 12px 30px rgba(10, 6, 30, .24)',
            glass: '0 24px 80px rgba(5, 5, 20, .22), inset 0 1px 0 rgba(255, 255, 255, .06)'
          },
          keyframes: {
            fadeInUp: {
              '0%': { opacity: '0', transform: 'translateY(16px)' },
              '100%': { opacity: '1', transform: 'translateY(0)' }
            }
          },
          animation: { 'fade-in-up': 'fadeInUp .65s cubic-bezier(.16,1,.3,1) both' }
        }
      }
    };
